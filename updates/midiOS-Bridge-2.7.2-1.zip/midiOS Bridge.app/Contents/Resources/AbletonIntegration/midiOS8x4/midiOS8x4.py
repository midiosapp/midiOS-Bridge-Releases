from _Framework.ControlSurface import ControlSurface
from _Framework.SessionComponent import SessionComponent
from _Framework.TransportComponent import TransportComponent
from _Framework.ButtonElement import ButtonElement
from _Framework.InputControlElement import MIDI_NOTE_TYPE, MIDI_CC_TYPE
from _Framework.SubjectSlot import subject_slot
from Live.Song import Quantization, RecordingQuantization

# --- Script Version ---
SCRIPT_BUILD = 30

# Private Remote Script identification protocol. Bridge asks with the SysEx
# signature below; the running script replies on the existing feedback channel
# with a framed five-CC message. CC 65..69 are reserved for this helper.
REMOTE_SCRIPT_QUERY = (0xF0, 0x7D, 0x4D, 0x4F, 0x53, 0x56, 0x00, 0xF7)
REMOTE_SCRIPT_PROTOCOL_VERSION = 1
CC_SCRIPT_ID_START = 65
CC_SCRIPT_ID_PROTOCOL = 66
CC_SCRIPT_ID_BUILD_MSB = 67
CC_SCRIPT_ID_BUILD_LSB = 68
CC_SCRIPT_ID_END = 69

# Correlated clip-action request/response protocol. Requests use a private
# non-commercial SysEx manufacturer ID and carry the exact visible grid cell.
# Results return as a four-CC frame on the established feedback channel.
CLIP_ACTION_HEADER = (0xF0, 0x7D, 0x4D, 0x4F, 0x53, 0x41)  # F0 7D "MOSA"
CLIP_ACTION_FRAME_VERSION = 1
CLIP_ACTION_QUANTIZE = 1
CLIP_ACTION_DUPLICATE_FROM_ABOVE = 2
CLIP_ACTION_GRID_SIXTEENTH = 1
CC_CLIP_ACTION_RESULT_START = 56
CC_CLIP_ACTION_RESULT_REQUEST_MSB = 57
CC_CLIP_ACTION_RESULT_REQUEST_LSB = 58
CC_CLIP_ACTION_RESULT_COMMIT = 59
CLIP_ACTION_RESULT_MAGIC = 0x51
CLIP_ACTION_RESULT_SUCCESS = 0
CLIP_ACTION_RESULT_EMPTY_SLOT = 1
CLIP_ACTION_RESULT_AUDIO_CLIP = 2
CLIP_ACTION_RESULT_RECORDING = 3
CLIP_ACTION_RESULT_INVALID_TARGET = 4
CLIP_ACTION_RESULT_UNSUPPORTED = 5
CLIP_ACTION_RESULT_LIVE_API_FAILURE = 6
CLIP_ACTION_RESULT_DESTINATION_OCCUPIED = 7

# --- CC map for track state feedback (must match MacMIDIListener.swift) ---
CC_ENABLE_BASE = 48   # 48..55  (col 0..7) -- clean range, no transport/clock/modifier overlap
CC_SOLO_BASE   = 88   # 88..95  (col 0..7)
CC_MUTE_BASE   = 96   # 96..103 (col 0..7)

# Legacy bitmask CCs are intentionally disabled to avoid collisions:
# 114 = metronome, 115 = tap tempo, 116 = scene bank up.
CC_SOLO_MASK   = None
CC_MUTE_MASK   = None
CC_ENABLE_MASK = None

# --- Timings (seconds) ---
# Make feedback much more responsive while keeping load reasonable
POLL_INITIAL_DELAY_SEC = 0.5   # was 10
GRID_SNAPSHOT_DELAY_SEC = 0.25 # was 1
COLOR_SNAPSHOT_DELAY_SEC = 0.5 # was 2
MIX_SNAPSHOT_DELAY_SEC = 0.5   # was 3
POLL_INTERVAL_SEC = 0.05       # fast polling for clip-state updates

# --- Mixer CC bases (visible 8 columns) ---
CC_VOL_BASE = 20      # 20..27
CC_SEND_A_BASE = 30   # 30..37
CC_SEND_B_BASE = 40   # 40..47

# --- Grid run-state feedback CCs (per cell) ---
# Sent on isolated MIDI channel 15 (0-based = 14) to avoid collisions.
RUNSTATE_CC_BASE = 96
RUNSTATE_CHANNEL = 14

def _clamp01(x):
    try:
        return 0.0 if x < 0.0 else 1.0 if x > 1.0 else float(x)
    except Exception:
        return 0.0

def _int7(x):
    try:
        return int(max(0, min(127, int(x))))
    except Exception:
        return 0

def _parse_clip_action_message(midi_bytes):
    """Parse one complete, 7-bit-safe MOSA clip-action request."""
    try:
        data = tuple(int(byte) for byte in midi_bytes)
    except Exception:
        return None

    if len(data) != 15:
        return None
    if data[:6] != CLIP_ACTION_HEADER or data[-1] != 0xF7:
        return None
    if any(byte < 0 or byte > 0x7F for byte in data[6:-1]):
        return None

    return {
        'version': data[6],
        'request_id': (data[7] << 7) | data[8],
        'action': data[9],
        'track': data[10],
        'scene': data[11],
        'grid': data[12],
        'amount': data[13]
    }

# --- CC map for visible track color headers (top-row "awning") ---
# Uses a small, unused CC range: 12..19 (col 0..7)
CC_TRACK_COLOR_BASE = 12
CC_SELECTED_TRACK = 11
CC_SELECTTRACK = 127
CC_TRACK_ENABLE = 107


# --- CC map for Device Macros (focused track's first device) ---
CC_MACRO_BASE = 70  # 70..77 map to Macro 1..8

# --- Clock / tempo feedback to bridge ---
# Tempo is now transmitted as 14‑bit so BPM values above 127 are supported.
# CC60 = Tempo MSB, CC61 = Tempo LSB
# CC62 = Beat phase (0–127 inside quarter note)
# CC63 = Beat index in bar (1–4 typical)
# CC64 = Bar counter (LSB only, wraps at 127)
CC_TEMPO_MSB = 60
CC_TEMPO_LSB = 61
CC_BEAT_PHASE = 62
CC_BEAT_INDEX = 63
CC_BAR_POS = 106


class MidiOS8x4(ControlSurface):
    def __init__(self, c_instance):
        super(MidiOS8x4, self).__init__(c_instance)
        self.log_message(">>> MidiOS8x4 loaded successfully! <<<")

        with self.component_guard():
            # NOTE: Launchpad script listens only on IDAM port, isolated from instrument traffic, using Channel 16
            self._channel = 15  # MIDI channel 16 (0-based index = 15)
            self._session = SessionComponent(num_tracks=8, num_scenes=4)
            self._session.set_offsets(0, 0)  # Start at top-left
            self.set_highlighting_session_component(self._session)  # Enable red box

            # Tell Live to allow outbound clip/LED feedback on channel 16
            self.set_feedback_channels([self._channel])

            # Track currently targeted slot (updated on last pad interaction)
            self._target_track = 0  # 0..7 within visible 8x4
            self._target_scene = 0  # 0..3 within visible 8x4

            # Install Select/Modifier action listeners on a reserved CC range (122..127)
            self._init_select_modifiers()

            # Allow the app to set target column/scene explicitly (no launch)
            self._init_select_targeting()

            self._transport = TransportComponent()

            # Set up clip launch grid with notes starting at 36 (top-left = 36)
            self._setup_clip_buttons()

            # --- Clip slot listeners for immediate feedback on state changes ---
            self._clip_listeners = []
            for scene_index in range(4):
                for track_index in range(8):
                    clip_slot = self._session.scene(scene_index).clip_slot(track_index)

                    def make_listener(si=scene_index, ti=track_index):
                        def _on_clip_state_changed():
                            self._emit_cell(si, ti)
                        return _on_clip_state_changed

                    listener = make_listener()

                    try:
                        clip_slot.add_has_clip_listener(listener)
                    except Exception:
                        pass
                    try:
                        clip_slot.add_color_listener(listener)
                    except Exception:
                        pass
                    try:
                        clip_slot.add_playing_status_listener(listener)
                    except Exception:
                        pass
                    try:
                        clip_slot.add_is_triggered_listener(listener)
                    except Exception:
                        pass
                    try:
                        clip_slot.add_is_recording_listener(listener)
                    except Exception:
                        pass

                    self._clip_listeners.append((clip_slot, listener))

            # Set up navigation buttons as CCs 100-103
            self._setup_navigation()

            # Set up transport controls as CCs 110-115
            self._setup_transport()

            # Set up scene bank up as CC 116
            self._setup_scene_bank_up()

            # Set up stop all clips as CC 117
            self._setup_stop_all()

            # Set up scene launch buttons as CC 118-121
            self._setup_scene_launch()

            # Set up mixer faders (CC 20–27: Volume, 30–37: Send A, 40–47: Send B)
            self._setup_mix_faders()
            # Extra delayed snapshot to ensure all faders update promptly
            self.schedule_message(MIX_SNAPSHOT_DELAY_SEC, self._emit_mix_snapshot)

            # --- Macros (focused track's first device) ---
            self._macro_buttons = []   # CC70..77
            self._macro_params  = [None]*8
            self._macro_listeners = []  # (param, callback)
            self._setup_macros()

            # Follow selected track to keep macros bound to its first device
            try:
                if not self.song().view.selected_track_has_listener(self._on_selected_track_changed):
                    self.song().view.add_selected_track_listener(self._on_selected_track_changed)
            except:
                pass
            # Initial bind + push
            self._bind_focused_device()
            self.schedule_message(COLOR_SNAPSHOT_DELAY_SEC, self._push_macro_values)
            self.schedule_message(COLOR_SNAPSHOT_DELAY_SEC, self._send_selected_track_feedback)

            self._arm_listeners = []
            self._install_track_arm_listeners()
            # Bind solo/mute/enable listeners for the 8 visible columns
            self._state_slots = []
            self._bind_track_state_listeners()
            # Push an initial snapshot of track states
            self._send_state_snapshot()
            try:
                if not self.song().tracks_has_listener(self._on_tracks_structure_changed):
                    self.song().add_tracks_listener(self._on_tracks_structure_changed)
            except:
                pass

            # Periodic grid feedback so clip presence/playing/recording reflects in the app
            self._feedback_polling = True
            self.schedule_message(POLL_INITIAL_DELAY_SEC, self._start_feedback_poll)
            # Immediate initial snapshot so UI updates right away
            self.schedule_message(GRID_SNAPSHOT_DELAY_SEC, self._emit_grid_snapshot)
            self.schedule_message(COLOR_SNAPSHOT_DELAY_SEC, self._emit_visible_track_colors)

            # --- Tempo listener / initial clock snapshot ---
            try:
                if not self.song().tempo_has_listener(self._on_tempo_changed):
                    self.song().add_tempo_listener(self._on_tempo_changed)
            except Exception as e:
                self.log_message(f"Tempo listener setup error: {e}")

            self.schedule_message(1, self._send_tempo_snapshot)
            self.schedule_message(1, self._send_clock_snapshot)
            self.schedule_message(1, self._send_remote_script_identity)

    def _init_select_targeting(self):
        """CC104 sets target TRACK (column 0..7 via value 1..8), CC105 sets target SCENE (row 0..3 via value 1..4)."""
        try:
            self._btn_target_track = ButtonElement(True, MIDI_CC_TYPE, self._channel, 104)
            self._btn_target_scene = ButtonElement(True, MIDI_CC_TYPE, self._channel, 105)
            self._btn_target_track.add_value_listener(self._set_target_track_value)
            self._btn_target_scene.add_value_listener(self._set_target_scene_value)
        except Exception as e:
            self.log_message(f"Select targeting setup error: {e}")

    def _send_cc(self, cc, val):
        status = 0xB0 + self._channel
        try:
            self._send_midi((status, int(cc) & 0x7F, int(val) & 0x7F))
        except Exception as e:
            self.log_message(f"_send_cc error cc={cc} val={val}: {e}")

    def _send_remote_script_identity(self):
        """Report the build of the script that Ableton Live is actually running."""
        build = max(0, min(16383, int(SCRIPT_BUILD)))
        self._send_cc(CC_SCRIPT_ID_START, 0x4D)  # M
        self._send_cc(CC_SCRIPT_ID_PROTOCOL, REMOTE_SCRIPT_PROTOCOL_VERSION)
        self._send_cc(CC_SCRIPT_ID_BUILD_MSB, (build >> 7) & 0x7F)
        self._send_cc(CC_SCRIPT_ID_BUILD_LSB, build & 0x7F)
        self._send_cc(CC_SCRIPT_ID_END, 0x53)  # S; commits the complete frame

    def _send_clip_action_result(self, request_id, result):
        request_id = max(0, min(16383, int(request_id)))
        self._send_cc(CC_CLIP_ACTION_RESULT_START, CLIP_ACTION_RESULT_MAGIC)
        self._send_cc(CC_CLIP_ACTION_RESULT_REQUEST_MSB, (request_id >> 7) & 0x7F)
        self._send_cc(CC_CLIP_ACTION_RESULT_REQUEST_LSB, request_id & 0x7F)
        self._send_cc(CC_CLIP_ACTION_RESULT_COMMIT, int(result) & 0x7F)

    def _handle_clip_action_request(self, request):
        request_id = request['request_id']
        result = CLIP_ACTION_RESULT_LIVE_API_FAILURE

        try:
            if request['version'] != CLIP_ACTION_FRAME_VERSION:
                result = CLIP_ACTION_RESULT_UNSUPPORTED
            elif not (0 <= request['track'] < 8 and 0 <= request['scene'] < 4):
                result = CLIP_ACTION_RESULT_INVALID_TARGET
            elif request['action'] == CLIP_ACTION_QUANTIZE:
                if request['grid'] != CLIP_ACTION_GRID_SIXTEENTH:
                    result = CLIP_ACTION_RESULT_UNSUPPORTED
                    self._send_clip_action_result(request_id, result)
                    return

                track_index, scene_index = self._resolve_indices(
                    scene_index=request['scene'],
                    track_index=request['track']
                )
                track, slot, _ = self._get_slot(track_index, scene_index)
                if track is None or slot is None:
                    result = CLIP_ACTION_RESULT_INVALID_TARGET
                elif not getattr(slot, 'has_clip', False):
                    result = CLIP_ACTION_RESULT_EMPTY_SLOT
                else:
                    clip = slot.clip
                    if not getattr(clip, 'is_midi_clip', False):
                        result = CLIP_ACTION_RESULT_AUDIO_CLIP
                    elif getattr(clip, 'is_recording', False):
                        result = CLIP_ACTION_RESULT_RECORDING
                    else:
                        amount = float(request['amount']) / 127.0
                        clip.quantize(
                            RecordingQuantization.rec_q_sixtenth,
                            amount
                        )
                        result = CLIP_ACTION_RESULT_SUCCESS
                        self.show_message("midiOS: Quantized clip to 1/16")
                        self.log_message(
                            "Clip action quantized visible track={} scene={} request={}".format(
                                request['track'], request['scene'], request_id
                            )
                        )
            elif request['action'] == CLIP_ACTION_DUPLICATE_FROM_ABOVE:
                if request['grid'] != 0 or request['amount'] != 0:
                    result = CLIP_ACTION_RESULT_UNSUPPORTED
                elif request['scene'] == 0:
                    # The source must remain spatially visible directly above
                    # the pressed destination; never reach outside the 8x4 box.
                    result = CLIP_ACTION_RESULT_INVALID_TARGET
                else:
                    track_index, destination_scene_index = self._resolve_indices(
                        scene_index=request['scene'],
                        track_index=request['track']
                    )
                    track, destination_slot, slots = self._get_slot(
                        track_index,
                        destination_scene_index
                    )
                    source_scene_index = destination_scene_index - 1

                    if track is None or destination_slot is None or slots is None:
                        result = CLIP_ACTION_RESULT_INVALID_TARGET
                    elif getattr(destination_slot, 'has_clip', False):
                        # ClipSlot.duplicate_clip_to can overwrite a target.
                        # Revalidate in Live immediately before the API call.
                        result = CLIP_ACTION_RESULT_DESTINATION_OCCUPIED
                    elif not (0 <= source_scene_index < len(slots)):
                        result = CLIP_ACTION_RESULT_INVALID_TARGET
                    else:
                        source_slot = slots[source_scene_index]
                        if not getattr(source_slot, 'has_clip', False):
                            result = CLIP_ACTION_RESULT_EMPTY_SLOT
                        elif getattr(source_slot.clip, 'is_recording', False):
                            result = CLIP_ACTION_RESULT_RECORDING
                        else:
                            source_slot.duplicate_clip_to(destination_slot)
                            result = CLIP_ACTION_RESULT_SUCCESS
                            self._emit_grid_snapshot()
                            self.schedule_message(2, self._emit_grid_snapshot)
                            self.show_message("midiOS: Copied clip down")
                            self.log_message(
                                "Clip action duplicated visible track={} source_scene={} destination_scene={} request={}".format(
                                    request['track'],
                                    request['scene'] - 1,
                                    request['scene'],
                                    request_id
                                )
                            )
            else:
                result = CLIP_ACTION_RESULT_UNSUPPORTED
        except Exception as e:
            result = CLIP_ACTION_RESULT_LIVE_API_FAILURE
            self.log_message(
                "Clip action error action={}: {}".format(
                    request.get('action'), e
                )
            )

        self._send_clip_action_result(request_id, result)

    def _send_tempo_snapshot(self):
        try:
            # Support full BPM range using 14‑bit value (0..16383)
            tempo = int(round(float(self.song().tempo)))
            tempo = max(0, min(16383, tempo))

            msb = (tempo >> 7) & 0x7F
            lsb = tempo & 0x7F

            self._send_cc(CC_TEMPO_MSB, msb)
            self._send_cc(CC_TEMPO_LSB, lsb)
        except Exception as e:
            self.log_message(f"Tempo snapshot error: {e}")

    def _on_tempo_changed(self):
        try:
            self._send_tempo_snapshot()
        except Exception as e:
            self.log_message(f"Tempo change error: {e}")

    def _send_clock_snapshot(self):
        try:
            song = self.song()

            # Fractional phase inside the current quarter note
            song_time = float(song.current_song_time)
            phase = song_time % 1.0
            phase_cc = int(max(0, min(127, round(phase * 127.0))))
            self._send_cc(CC_BEAT_PHASE, phase_cc)

            # Beat + bar information using Ableton beat time structure
            beats = song.get_current_beats_song_time()
            beat_index = int(getattr(beats, "beats", 1))
            bar_index = int(getattr(beats, "bars", 0))

            # Clamp for MIDI CC range
            beat_cc = max(0, min(127, beat_index))
            bar_cc = max(0, min(127, bar_index))

            self._send_cc(CC_BEAT_INDEX, beat_cc)
            self._send_cc(CC_BAR_POS, bar_cc)

        except Exception as e:
            self.log_message(f"Clock snapshot error: {e}")

    def _any_track_armed(self):
        try:
            return any(getattr(t, "arm", False) for t in self.song().tracks if getattr(t, "can_be_armed", False))
        except Exception:
            return False

    def _broadcast_arm_state(self):
        val = 127 if self._any_track_armed() else 0
        self._send_cc(112, val)
        # Also broadcast per-visible-track arm states on CC80..87
        self._broadcast_per_track_arms()

    def _broadcast_per_track_arms(self):
        """Emit per-visible-track arm state as CC80..CC87 (127 if armed, else 0).
        Maps to the 8 columns of the current 8x4 session box using track_offset().
        """
        base_cc = 80
        try:
            off = int(self._session.track_offset())
        except Exception:
            off = 0
        tracks = list(self.song().tracks)
        for i in range(8):
            ti = off + i
            val = 0
            if 0 <= ti < len(tracks):
                t = tracks[ti]
                if getattr(t, "can_be_armed", False) and getattr(t, "arm", False):
                    val = 127
            # minimal debug: flip to True temporarily if you need to verify
            if False:
                try:
                    self.log_message(f"ARM SNAP i={i} ti={ti} val={val}")
                except Exception:
                    pass
            self._send_cc(base_cc + i, val)

    def _install_track_arm_listeners(self):
        if hasattr(self, "_arm_listeners") and self._arm_listeners:
            for (trk, cb) in self._arm_listeners:
                try:
                    if trk.arm_has_listener(cb):
                        trk.remove_arm_listener(cb)
                except Exception:
                    pass
        self._arm_listeners = []

        def make_cb():
            def _on_arm_changed():
                self._broadcast_arm_state()
            return _on_arm_changed

        for t in self.song().tracks:
            try:
                if getattr(t, "can_be_armed", False):
                    cb = make_cb()
                    if not t.arm_has_listener(cb):
                        t.add_arm_listener(cb)
                    self._arm_listeners.append((t, cb))
            except Exception:
                pass

        self._broadcast_arm_state()

    def _on_tracks_structure_changed(self):
        self._install_track_arm_listeners()
        self._emit_grid_snapshot()
        # also refresh mixer feedback
        self._emit_mix_snapshot()
        self._bind_track_state_listeners()
        self._send_state_snapshot()
        self._emit_visible_track_colors()
        # Rebind macros and push values whenever the track structure changes
        self._bind_focused_device()
        self._push_macro_values()
        self._send_selected_track_feedback()
        self._broadcast_arm_state()  # send after other updates so ARM wins

    def _slot_state(self, scene_index, track_index):
        """Return encoded state for (scene_index, track_index) in the VISIBLE 8x4 box.
        0 = empty, 1 = has clip (stopped), 2 = playing, 3 = recording.
        Uses song() with session offsets to ensure correctness.
        """
        try:
            ti = self._session.track_offset() + track_index
            si = self._session.scene_offset() + scene_index
            tracks = list(self.song().tracks)
            if ti < 0 or ti >= len(tracks):
                return 0
            slots = list(tracks[ti].clip_slots)
            if si < 0 or si >= len(slots):
                return 0
            slot = slots[si]
            if not getattr(slot, 'has_clip', False):
                return 0
            clip = slot.clip
            if getattr(clip, 'is_recording', False):
                return 3
            if getattr(clip, 'is_playing', False):
                return 2
            # has clip but not playing/recording
            return 1
        except Exception:
            return 0

    def _setup_clip_buttons(self):
        for scene_index in range(4):
            for track_index in range(8):
                note = 36 + scene_index * 8 + track_index
                button = ButtonElement(True, MIDI_NOTE_TYPE, self._channel, note)
                self._session.scene(scene_index).clip_slot(track_index).set_launch_button(button)
                button.add_value_listener(self._clip_feedback, identify_sender=True)

    def _setup_navigation(self):
        left_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 100)  # Left
        right_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 101)  # Right
        up_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 102)    # Up
        down_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 103)  # Down

        left_button.add_value_listener(self._nav_left_value)
        right_button.add_value_listener(self._nav_right_value)
        up_button.add_value_listener(self._nav_up_value)
        down_button.add_value_listener(self._nav_down_value)

    def _nav_left_value(self, value):
        if value > 0:
            track_offset = max(0, self._session.track_offset() - 1)
            self._session.set_offsets(track_offset, self._session.scene_offset())
            self._emit_grid_snapshot()
            self._broadcast_arm_state()
            self._emit_mix_snapshot()
            self._bind_track_state_listeners()
            self._send_state_snapshot()
            self._emit_visible_track_colors()
            self._send_selected_track_feedback()

    def _nav_right_value(self, value):
        if value > 0:
            track_offset = self._session.track_offset() + 1
            self._session.set_offsets(track_offset, self._session.scene_offset())
            self._emit_grid_snapshot()
            self._broadcast_arm_state()
            self._emit_mix_snapshot()
            self._bind_track_state_listeners()
            self._send_state_snapshot()
            self._emit_visible_track_colors()
            self._send_selected_track_feedback()

    def _nav_up_value(self, value):
        if value > 0:
            scene_offset = max(0, self._session.scene_offset() - 1)
            self._session.set_offsets(self._session.track_offset(), scene_offset)
            self._emit_grid_snapshot()
            self._broadcast_arm_state()
            self._emit_mix_snapshot()
            self._bind_track_state_listeners()
            self._send_state_snapshot()
            self._emit_visible_track_colors()
            self._send_selected_track_feedback()

    def _nav_down_value(self, value):
        if value > 0:
            scene_offset = self._session.scene_offset() + 1
            self._session.set_offsets(self._session.track_offset(), scene_offset)
            self._emit_grid_snapshot()
            self._broadcast_arm_state()
            self._emit_mix_snapshot()
            self._bind_track_state_listeners()
            self._send_state_snapshot()
            self._emit_visible_track_colors()
            self._send_selected_track_feedback()

    def _handle_scene_command(self, cmd):
        """
        Supported commands (ASCII):
          'next'         -> move visible 8x4 window down by 1 scene
          'prev'         -> move visible 8x4 window up by 1 scene
          'jump:<num>'   -> make scene <num> (1-based) the TOP row of the visible 8x4 window
          'launch'       -> fire the TOP visible scene (scene_offset)
          'launch:<num>' -> fire scene <num> (1-based)
        """
        try:
            cmd_l = (cmd or '').strip().lower()
            if cmd_l == 'next':
                new_off = int(self._session.scene_offset()) + 1
                self._set_scene_offset_safe(new_off)

            elif cmd_l in ('prev', 'last', 'previous'):
                new_off = max(0, int(self._session.scene_offset()) - 1)
                self._set_scene_offset_safe(new_off)

            elif cmd_l.startswith('jump:'):
                try:
                    num = int(cmd_l.split(':', 1)[1])
                except Exception:
                    num = None
                if num is not None and num >= 1:
                    self._set_scene_offset_safe(num - 1)

            elif cmd_l == 'launch':
                off = int(self._session.scene_offset())
                scenes = list(self.song().scenes)
                if 0 <= off < len(scenes):
                    scenes[off].fire()

            elif cmd_l.startswith('launch:'):
                try:
                    num = int(cmd_l.split(':', 1)[1])
                except Exception:
                    num = None
                scenes = list(self.song().scenes)
                if num is not None and num >= 1 and num - 1 < len(scenes):
                    scenes[num - 1].fire()

        except Exception as e:
            try:
                self.log_message(f"_handle_scene_command error: {e}")
            except Exception:
                pass

    def _set_scene_offset_safe(self, new_offset):
        """Clamp and apply scene_offset, then refresh all UI/state snapshots."""
        try:
            # Determine max allowed offset so that the 8x4 window remains valid
            scenes = list(self.song().scenes)
            max_off = max(0, len(scenes) - 4)
            off = max(0, min(int(new_offset), max_off))
            self._session.set_offsets(self._session.track_offset(), off)
            # Mirror the same refresh sequence used in navigation handlers
            self._emit_grid_snapshot()
            self._broadcast_arm_state()
            self._emit_mix_snapshot()
            self._bind_track_state_listeners()
            self._send_state_snapshot()
            self._emit_visible_track_colors()
            self._send_selected_track_feedback()
        except Exception as e:
            try:
                self.log_message(f"_set_scene_offset_safe error: {e}")
            except Exception:
                pass

    # ---------- Track State (Solo / Mute / Enable) Feedback ----------

    def _visible_tracks(self):
        try:
            off = int(self._session.track_offset())
        except Exception:
            off = 0
        tracks = list(self.song().tracks)
        return tracks[off:off+8]
        
    def _send_selected_track_feedback(self):
        try:
            selected = self.song().view.selected_track
            visible = self._visible_tracks()

            idx = visible.index(selected) if selected in visible else -1

            # 1..8 visible columns, 0 = not visible
            self._send_cc(CC_SELECTED_TRACK, idx + 1 if idx >= 0 else 0)

        except Exception as e:
            self.log_message(f"Selected track feedback error: {e}")

    def _unbind_state_slots(self):
        for slot in getattr(self, "_state_slots", []):
            try:
                slot.disconnect()
            except Exception:
                pass
        self._state_slots = []

    def _bind_track_state_listeners(self):
        # Rebind listeners for currently visible 8 columns
        self._unbind_state_slots()
        tracks = self._visible_tracks()

        for idx, track in enumerate(tracks):
            try:
                # SOLO listener
                solo_slot = subject_slot(self._on_solo_changed)
                solo_slot.subject = track
                self._state_slots.append(solo_slot)

                # MUTE listener
                mute_slot = subject_slot(self._on_mute_changed)
                mute_slot.subject = track
                self._state_slots.append(mute_slot)

                # ENABLE (Track Activator) listener (DeviceParameter value 0.0/1.0)
                activator = track.mixer_device.track_activator
                enable_slot = subject_slot(self._on_enable_changed)
                enable_slot.subject = activator
                self._state_slots.append(enable_slot)
            except Exception as e:
                self.log_message("State bind err trk %d: %s" % (idx, e))

        # Send a full snapshot each time we rebind
        self._send_state_snapshot()

    def _on_solo_changed(self):
        track = self._on_solo_changed.subject
        tracks = self._visible_tracks()
        col = tracks.index(track) if track in tracks else -1
        if col >= 0:
            self._emit_track_solo(col, track)

    def _on_mute_changed(self):
        track = self._on_mute_changed.subject
        tracks = self._visible_tracks()
        col = tracks.index(track) if track in tracks else -1
        if col >= 0:
            self._emit_track_mute(col, track)

    def _on_enable_changed(self):
        param = self._on_enable_changed.subject
        track = param.canonical_parent.canonical_parent  # Device -> Mixer -> Track
        tracks = self._visible_tracks()
        col = tracks.index(track) if track in tracks else -1
        if col >= 0:
            self._emit_track_enable(col, param)

    def _emit_track_solo(self, col, track):
        try:
            val = 127 if bool(getattr(track, 'solo', False)) else 0
            self._send_cc(CC_SOLO_BASE + int(col), val)
        except Exception as e:
            self.log_message("emit solo err: %s" % e)

    def _emit_track_mute(self, col, track):
        try:
            val = 127 if bool(getattr(track, 'mute', False)) else 0
            self._send_cc(CC_MUTE_BASE + int(col), val)
        except Exception as e:
            self.log_message("emit mute err: %s" % e)

    def _emit_track_enable(self, col, activator_param):
        try:
            val = 127 if float(getattr(activator_param, 'value', 0.0)) >= 0.5 else 0
            self._send_cc(CC_ENABLE_BASE + int(col), val)
        except Exception as e:
            self.log_message("emit enable err: %s" % e)

    def _send_state_snapshot(self):
        # Emit per-column solo/mute/enable state. Bitmask feedback is disabled to avoid CC collisions.
        tracks = self._visible_tracks()
        for i, t in enumerate(tracks[:8]):
            self._emit_track_solo(i, t)
            self._emit_track_mute(i, t)
            try:
                self._emit_track_enable(i, t.mixer_device.track_activator)
            except Exception as e:
                self.log_message("snapshot enable err trk %d: %s" % (i, e))

    def _setup_transport(self):
        play_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 110)
        self._transport.set_play_button(play_button)

        stop_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 111)
        self._transport.set_stop_button(stop_button)
        stop_button.add_value_listener(self._stop_value)

        rec_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 112)
        self._transport.set_record_button(rec_button)

        # --- Session Record toggle (CC109) ---
        session_rec_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 109)
        session_rec_button.add_value_listener(self._toggle_session_record_value)
        self._session_rec_button = session_rec_button

        # CC113: Overdub toggle instead of loop
        self._overdub_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 113)
        self._overdub_button.add_value_listener(self._toggle_overdub_value)

        metro_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 114)
        self._transport.set_metronome_button(metro_button)

        tap_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 115)
        self._transport.set_tap_tempo_button(tap_button)
        tap_button.add_value_listener(self._tap_value)

        # Loop toggle button (CC108)
        loop_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 108)
        loop_button.add_value_listener(self._toggle_loop_value)
        self._loop_button = loop_button

    def _toggle_session_record_value(self, value):
        if value > 0:
            try:
                self.song().session_record = not self.song().session_record
            except Exception as e:
                self.log_message(f"Session Record toggle error: {e}")
            try:
                self._send_midi((0xB0 + self._channel, 109, 90))
                self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 109, 0)))
            except Exception:
                pass


    def _toggle_overdub_value(self, value):
        """Toggle session overdub on value > 0, send flash feedback."""
        if value > 0:
            try:
                self.song().overdub = not self.song().overdub
            except Exception as e:
                self.log_message(f"Overdub toggle error: {e}")
            # Flash feedback (similar to _stop_value)
            try:
                self._send_midi((0xB0 + self._channel, 113, 90))  # Flash color
                self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 113, 0)))
            except Exception:
                pass

    def _stop_value(self, value):
        if value > 0:
            self._send_midi((0xB0 + self._channel, 111, 90))  # Flash orange
            self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 111, 0)))

    def _tap_value(self, value):
        if value > 0:
            self._send_midi((0xB0 + self._channel, 115, 90))  # Flash yellow
            self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 115, 0)))

    def _delete_clip_value(self, value):
        v = int(value)
        if v <= 0:
            return

        # Bulk delete: value==3 means delete everything in the visible 8×4
        if v == 3:
            try:
                track_off = self._session.track_offset()
                scene_off = self._session.scene_offset()
                tracks = list(self.song().tracks)

                for ti in range(track_off, min(track_off + 8, len(tracks))):
                    slots = list(tracks[ti].clip_slots)
                    for si in range(scene_off, min(scene_off + 4, len(slots))):
                        slot = slots[si]
                        if getattr(slot, "has_clip", False):
                            try:
                                if getattr(slot.clip, "is_recording", False):
                                    slot.fire()
                                slot.delete_clip()
                            except Exception:
                                pass

                self._emit_grid_snapshot()
            except Exception as e:
                self.log_message(f"Bulk delete (8x4) error: {e}")
            return

        # Default single-slot delete behavior
        ti, si = self._resolve_indices()
        track, slot, _ = self._get_slot(ti, si)
        if slot and getattr(slot, "has_clip", False):
            try:
                if getattr(slot.clip, 'is_recording', False):
                    slot.fire()
                slot.delete_clip()
                # Immediate refresh of the visible cell
                vis_scene = si - self._session.scene_offset()
                vis_track = ti - self._session.track_offset()
                if 0 <= vis_scene < 4 and 0 <= vis_track < 8:
                    self._emit_cell(vis_scene, vis_track)
                    # Deferred refresh (Live can report stale state for a frame in debug)
                    self.schedule_message(2, lambda: self._emit_cell(vis_scene, vis_track))
                else:
                    # If indices are outside the visible window, refresh the whole grid
                    self._emit_grid_snapshot()
            except Exception as e:
                self.log_message(f"Delete clip error: {e}")

    def _duplicate_clip_value(self, value):
        if value <= 0:
            return
        ti, si = self._resolve_indices()
        track, slot, _ = self._get_slot(ti, si)
        if not slot or not getattr(slot, 'has_clip', False):
            return
        dst = self._next_empty_scene_in_track(ti, si)
        if dst is None:
            return
        try:
            tracks = list(self.song().tracks)
            dst_slot = list(tracks[ti].clip_slots)[dst]
            slot.duplicate_clip_to(dst_slot)
            # refresh both source and destination cells in the visible box if applicable
            self._emit_grid_snapshot()
        except Exception as e:
            self.log_message(f"Duplicate clip error: {e}")

    def _toggle_mute_value(self, value):
        if value <= 0:
            return
        ti, _ = self._resolve_indices()
        track, _, _ = self._get_slot(ti, 0)
        if track is None:
            return
        try:
            track.mute = not bool(getattr(track, 'mute', False))
            self._send_state_snapshot()
        except Exception as e:
            self.log_message(f"Toggle mute error: {e}")
            
    def _toggle_track_enable_value(self, value):
        if value <= 0:
            return

        ti, _ = self._resolve_indices()
        track, _, _ = self._get_slot(ti, 0)

        if track is None:
            return

        try:
            activator = track.mixer_device.track_activator
            activator.value = 0.0 if float(activator.value) >= 0.5 else 1.0

            # Immediate feedback to iOS
            tracks = self._visible_tracks()
            col = tracks.index(track) if track in tracks else -1
            if col >= 0:
                self._emit_track_enable(col, activator)

            # Keep global state synchronized
            self._send_state_snapshot()

        except Exception as e:
            self.log_message(f"Toggle track enable error: {e}")

    def _toggle_solo_value(self, value):
        if value <= 0:
            return
        ti, _ = self._resolve_indices()
        track, _, _ = self._get_slot(ti, 0)
        if track is None:
            return
        try:
            if int(value) == 2:
                # SOLO EXCLUSIVE: clear all solos first
                for t in self.song().tracks:
                    try:
                        t.solo = False
                    except Exception:
                        pass
                track.solo = True
                self._send_state_snapshot()
            else:
                track.solo = not bool(getattr(track, 'solo', False))
                self._send_state_snapshot()
        except Exception as e:
            self.log_message(f"Toggle solo error: {e}")

    def _toggle_arm_value(self, value):
        if value <= 0:
            return
        ti, _ = self._resolve_indices()
        track, _, _ = self._get_slot(ti, 0)
        if track is None or not getattr(track, 'can_be_armed', False):
            return
        try:
            if int(value) == 2:
                # ARM EXCLUSIVE: disarm all arming-capable tracks, then arm this one
                for t in self.song().tracks:
                    if getattr(t, 'can_be_armed', False):
                        try:
                            t.arm = False
                        except Exception:
                            pass
                track.arm = True
            else:
                track.arm = not bool(getattr(track, 'arm', False))
            self._broadcast_arm_state()
        except Exception as e:
            self.log_message(f"Toggle arm error: {e}")

    def _select_track_value(self, value):
        if value <= 0:
            return

        ti, _ = self._resolve_indices()
        track, _, _ = self._get_slot(ti, 0)

        if track is None:
            return

        try:
            self.song().view.selected_track = track

            try:
                self.song().view.selected_scene = self.song().scenes[
                    self._session.scene_offset() + self._target_scene
                ]
            except Exception:
                pass

            self._bind_focused_device()
            self._push_macro_values()
            self._send_selected_track_feedback()

        except Exception as e:
            self.log_message(f"Track select error: {e}")

    def _setup_scene_bank_up(self):
        scene_up_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 116)
        scene_up_button.add_value_listener(self._scene_bank_up_value)

    def _scene_bank_up_value(self, value):
        if value > 0:
            scene_offset = max(0, self._session.scene_offset() - 4)
            self._session.set_offsets(self._session.track_offset(), scene_offset)
            # Full refresh so the 8x4 view, colors, and faders update immediately
            self._emit_grid_snapshot()
            self._broadcast_arm_state()
            self._emit_mix_snapshot()
            self._bind_track_state_listeners()
            self._send_state_snapshot()
            self._emit_visible_track_colors()
            self._send_selected_track_feedback()
            # Flash feedback
            self._send_midi((0xB0 + self._channel, 116, 90))
            self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 116, 0)))

    def _setup_stop_all(self):
        stop_all_button = ButtonElement(True, MIDI_CC_TYPE, self._channel, 117)
        stop_all_button.add_value_listener(self._stop_all_value)

    def _stop_all_value(self, value):
        if value > 0:
            self.song().stop_all_clips()
            self._send_midi((0xB0 + self._channel, 117, 90))  # Flash
            self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 117, 0)))

    def _setup_scene_launch(self):
        for i, cc in enumerate([118, 119, 120, 121]):
            btn = ButtonElement(True, MIDI_CC_TYPE, self._channel, cc)
            self._session.scene(i).set_launch_button(btn)

    # ========================= Macros (first device on selected track) =========================
    def _setup_macros(self):
        try:
            for i in range(8):
                cc = CC_MACRO_BASE + i
                btn = ButtonElement(True, MIDI_CC_TYPE, self._channel, cc)
                btn.add_value_listener(self._on_macro_cc, identify_sender=True)
                self._macro_buttons.append(btn)
        except Exception as e:
            self.log_message(f"Macro setup error: {e}")

    def _clear_macro_param_listeners(self):
        try:
            for (p, cb) in getattr(self, '_macro_listeners', []):
                try:
                    if p and p.value_has_listener(cb):
                        p.remove_value_listener(cb)
                except Exception:
                    pass
        finally:
            self._macro_listeners = []

    def _bind_focused_device(self):
        """Bind first device of selected track to macro params and attach value listeners."""
        self._clear_macro_param_listeners()
        self._macro_params = [None]*8
        try:
            track = self.song().view.selected_track
            devs = list(getattr(track, 'devices', [])) if track else []
            dev = devs[0] if len(devs) > 0 else None
            if dev is None:
                return
            params = list(getattr(dev, 'parameters', []))
            usable = []
            if len(params) >= 8:
                first_name = (getattr(params[0], 'name', '') or '').strip().lower()
                if len(params) >= 9 and first_name in ('device on', 'on', 'device on/off', 'power'):
                    usable = params[1:9]
                else:
                    usable = params[:8]
            else:
                usable = params

            for i in range(8):
                p = usable[i] if i < len(usable) else None
                self._macro_params[i] = p
                if p is None:
                    continue
                def _make_cb(idx):
                    def _on_val():
                        self._send_macro_cc(idx)
                    return _on_val
                cb = _make_cb(i)
                try:
                    p.add_value_listener(cb)
                    self._macro_listeners.append((p, cb))
                except Exception:
                    pass
        except Exception as e:
            self.log_message(f"bind_focused_device error: {e}")

    def _on_selected_track_changed(self):
        try:
            self._bind_focused_device()
            self._push_macro_values()
            self._send_selected_track_feedback()
        except Exception as e:
            self.log_message(f"selected_track change error: {e}")

    def _norm_from_param(self, p):
        try:
            pmin = float(getattr(p, 'min', 0.0))
            pmax = float(getattr(p, 'max', 1.0))
            rng = (pmax - pmin) if (pmax - pmin) != 0 else 1.0
            return max(0.0, min(1.0, (float(p.value) - pmin) / rng))
        except Exception:
            return 0.0

    def _value_to_param(self, p, value):
        try:
            pmin = float(getattr(p, 'min', 0.0))
            pmax = float(getattr(p, 'max', 1.0))
            v01 = max(0.0, min(1.0, float(int(value) & 0x7F) / 127.0))
            p.value = pmin + v01 * (pmax - pmin)
        except Exception:
            pass

    def _send_macro_cc(self, idx):
        try:
            p = self._macro_params[idx]
            if p is None:
                return
            v = int(round(self._norm_from_param(p) * 127.0))
            self._send_cc(CC_MACRO_BASE + idx, v)
        except Exception as e:
            self.log_message(f"send_macro_cc error idx {idx}: {e}")

    def _push_macro_values(self):
        for i in range(8):
            self._send_macro_cc(i)

    def _on_macro_cc(self, value, sender=None):
        try:
            cc = sender.message_identifier() if sender else None
            if cc is None or cc < CC_MACRO_BASE or cc > CC_MACRO_BASE + 7:
                return
            idx = int(cc - CC_MACRO_BASE)
            p = self._macro_params[idx] if idx < len(self._macro_params) else None
            if p is None:
                return
            self._value_to_param(p, value)
        except Exception as e:
            self.log_message(f"Macro CC error: {e}")

    def receive_midi(self, midi_bytes):
        """
        Handle inbound MIDI from the iOS app. We parse compact SysEx scene commands:
        Format: F0 7D 53 43 <ascii bytes 'next'|'prev'|'jump:x'> F7
        """

        # Direct CC path for Macros: apply and echo the same value immediately (prevents UI snap)
        try:
            status = midi_bytes[0]
            data1  = midi_bytes[1] if len(midi_bytes) > 1 else 0
            data2  = midi_bytes[2] if len(midi_bytes) > 2 else 0
            if (status & 0xF0) == 0xB0 and (status & 0x0F) == self._channel and CC_MACRO_BASE <= data1 <= CC_MACRO_BASE + 7:
                idx = data1 - CC_MACRO_BASE
                val = int(data2) & 0x7F
                if 0 <= idx < len(getattr(self, '_macro_params', [])):
                    p = self._macro_params[idx]
                    if p is not None:
                        self._value_to_param(p, val)
                # Echo back immediately so the app's knob stays where user left it
                self._send_cc(CC_MACRO_BASE + idx, val)
                return
        except Exception:
            pass

        try:
            # Ensure tuple/bytes
            data = tuple(midi_bytes) if not isinstance(midi_bytes, tuple) else midi_bytes
            if data == REMOTE_SCRIPT_QUERY:
                self._send_remote_script_identity()
                return
            if len(data) >= 6 and data[:6] == CLIP_ACTION_HEADER:
                request = _parse_clip_action_message(data)
                if request is not None:
                    self._handle_clip_action_request(request)
                return
            if len(data) >= 6 and data[0] == 0xF0 and data[-1] == 0xF7 and data[1] == 0x7D and data[2] == 0x53 and data[3] == 0x43:
                # Extract ASCII payload between header (4 bytes) and F7
                try:
                    payload_bytes = data[4:-1]
                    cmd = ''.join(chr(b & 0x7F) for b in payload_bytes).strip()
                except Exception:
                    cmd = ''
                if cmd:
                    self._handle_scene_command(cmd)
                return
        except Exception as e:
            try:
                self.log_message(f"receive_midi parse error: {e}")
            except Exception:
                pass
        # Fallback to base handling
        try:
            super(MidiOS8x4, self).receive_midi(midi_bytes)
        except Exception:
            pass

    # ========================= Mixer Faders (Vol / Send A / Send B) =========================

    def _setup_mix_faders(self):
        """Bind CC 20–27 to visible track volumes, 30–37 to Send A, 40–47 to Send B (absolute CC on self._channel)."""
        try:
            self._vol_ccs   = [CC_VOL_BASE + i for i in range(8)]
            self._sendA_ccs = [CC_SEND_A_BASE + i for i in range(8)]
            self._sendB_ccs = [CC_SEND_B_BASE + i for i in range(8)]

            self._vol_buttons   = []
            self._sendA_buttons = []
            self._sendB_buttons = []

            for cc in self._vol_ccs:
                btn = ButtonElement(True, MIDI_CC_TYPE, self._channel, cc)
                btn.add_value_listener(self._on_volume_cc, identify_sender=True)
                self._vol_buttons.append(btn)

            for cc in self._sendA_ccs:
                btn = ButtonElement(True, MIDI_CC_TYPE, self._channel, cc)
                btn.add_value_listener(self._on_send_a_cc, identify_sender=True)
                self._sendA_buttons.append(btn)

            for cc in self._sendB_ccs:
                btn = ButtonElement(True, MIDI_CC_TYPE, self._channel, cc)
                btn.add_value_listener(self._on_send_b_cc, identify_sender=True)
                self._sendB_buttons.append(btn)

            # Prime the iOS UI with current values
            self._emit_mix_snapshot()
        except Exception as e:
            self.log_message(f"Fader setup error: {e}")

    # ---- CC handlers (absolute 0..127) -------------------------------------

    def _on_volume_cc(self, value, sender=None):
        try:
            cc = sender.message_identifier() if sender else None
            if cc is None or cc < CC_VOL_BASE or cc > CC_VOL_BASE + 7:
                return
            col = cc - CC_VOL_BASE
            ti = int(self._session.track_offset()) + col
            tracks = list(self.song().tracks)
            if 0 <= ti < len(tracks):
                param = tracks[ti].mixer_device.volume
                param.value = float(int(value) & 0x7F) / 127.0
                # Echo actual value back so UI stays glued to Live
                v = _int7(_clamp01(param.value) * 127)
                self._send_cc(cc, v)
        except Exception as e:
            self.log_message(f"Volume CC error: {e}")

    def _on_send_a_cc(self, value, sender=None):
        try:
            cc = sender.message_identifier() if sender else None
            if cc is None or cc < CC_SEND_A_BASE or cc > CC_SEND_A_BASE + 7:
                return
            col = cc - CC_SEND_A_BASE
            ti = int(self._session.track_offset()) + col
            tracks = list(self.song().tracks)
            if 0 <= ti < len(tracks):
                sends = list(tracks[ti].mixer_device.sends)
                if len(sends) >= 1:
                    sends[0].value = float(int(value) & 0x7F) / 127.0
                    a = _int7(_clamp01(sends[0].value) * 127)
                    self._send_cc(cc, a)
        except Exception as e:
            self.log_message(f"Send A CC error: {e}")

    def _on_send_b_cc(self, value, sender=None):
        try:
            cc = sender.message_identifier() if sender else None
            if cc is None or cc < CC_SEND_B_BASE or cc > CC_SEND_B_BASE + 7:
                return
            col = cc - CC_SEND_B_BASE
            ti = int(self._session.track_offset()) + col
            tracks = list(self.song().tracks)
            if 0 <= ti < len(tracks):
                sends = list(tracks[ti].mixer_device.sends)
                if len(sends) >= 2:
                    sends[1].value = float(int(value) & 0x7F) / 127.0
                    b = _int7(_clamp01(sends[1].value) * 127)
                    self._send_cc(cc, b)
        except Exception as e:
            self.log_message(f"Send B CC error: {e}")

    # ---- Feedback to the app -----------------------------------------------

    def _emit_mix_snapshot(self):
        """Echo visible mixer values as CC so the iOS faders stay in sync."""
        try:
            tracks = list(self.song().tracks)
            off = int(self._session.track_offset())
            for i in range(8):
                ti = off + i
                if 0 <= ti < len(tracks):
                    mix = tracks[ti].mixer_device
                    # Volume
                    v = _int7(_clamp01(mix.volume.value) * 127)
                    self._send_cc(CC_VOL_BASE + i, v)
                    # Sends
                    sends = list(mix.sends)
                    if len(sends) >= 1:
                        a = _int7(_clamp01(sends[0].value) * 127)
                        self._send_cc(CC_SEND_A_BASE + i, a)
                    if len(sends) >= 2:
                        b = _int7(_clamp01(sends[1].value) * 127)
                        self._send_cc(CC_SEND_B_BASE + i, b)
                else:
                    # No track in this visible column—clear UI
                    self._send_cc(CC_VOL_BASE + i, 0)
                    self._send_cc(CC_SEND_A_BASE + i, 0)
                    self._send_cc(CC_SEND_B_BASE + i, 0)
        except Exception as e:
            self.log_message(f"Mix snapshot error: {e}")

    def _init_select_modifiers(self):
        """Reserve CC 122..127 on channel 16 for Select-modifier actions.
        CC122: delete clip in targeted slot; value==3 deletes all visible clips (8x4)
        CC123: duplicate clip to next empty slot in same track
        CC124: toggle track mute (target column)
        CC125: toggle track solo (target column) — value=2 means SOLO EXCLUSIVE
        CC126: toggle track arm  (target column) — value=2 means ARM  EXCLUSIVE
        CC107: toggle track activator (target column)
        CC127: select/focus target track in Ableton UI
        """
        try:
            self._btn_delete = ButtonElement(True, MIDI_CC_TYPE, self._channel, 122)
            self._btn_duplicate = ButtonElement(True, MIDI_CC_TYPE, self._channel, 123)
            self._btn_mute = ButtonElement(True, MIDI_CC_TYPE, self._channel, 124)
            self._btn_solo = ButtonElement(True, MIDI_CC_TYPE, self._channel, 125)
            self._btn_arm = ButtonElement(True, MIDI_CC_TYPE, self._channel, 126)
            self._btn_track_enable = ButtonElement(True, MIDI_CC_TYPE, self._channel, CC_TRACK_ENABLE)
            self._btn_track_select = ButtonElement(True, MIDI_CC_TYPE, self._channel, CC_SELECTTRACK)
            self._btn_delete.add_value_listener(self._delete_clip_value)
            self._btn_duplicate.add_value_listener(self._duplicate_clip_value)
            self._btn_mute.add_value_listener(self._toggle_mute_value)
            self._btn_solo.add_value_listener(self._toggle_solo_value)
            self._btn_arm.add_value_listener(self._toggle_arm_value)
            self._btn_track_enable.add_value_listener(self._toggle_track_enable_value)
            self._btn_track_select.add_value_listener(self._select_track_value)
        except Exception as e:
            self.log_message(f"Select modifier setup error: {e}")

    def _resolve_indices(self, scene_index=None, track_index=None):
        """Map visible (0..3, 0..7) indices to absolute song indices using session offsets.
        Defaults to last targeted indices if none provided.
        Returns tuple (abs_track_idx, abs_scene_idx) or (None, None).
        """
        try:
            ti = self._session.track_offset() + (self._target_track if track_index is None else track_index)
            si = self._session.scene_offset() + (self._target_scene if scene_index is None else scene_index)
            return ti, si
        except Exception:
            return None, None

    def _get_slot(self, abs_track_idx, abs_scene_idx):
        try:
            tracks = list(self.song().tracks)
            if abs_track_idx < 0 or abs_track_idx >= len(tracks):
                return None, None, None
            track = tracks[abs_track_idx]
            slots = list(track.clip_slots)
            if abs_scene_idx < 0 or abs_scene_idx >= len(slots):
                return track, None, None
            return track, slots[abs_scene_idx], slots
        except Exception:
            return None, None, None

    def _next_empty_scene_in_track(self, abs_track_idx, start_scene_idx):
        track, _, slots = self._get_slot(abs_track_idx, start_scene_idx)
        if track is None or slots is None:
            return None
        for si in range(start_scene_idx + 1, len(slots)):
            try:
                if not slots[si].has_clip:
                    return si
            except Exception:
                pass
        return None

    def _clip_color_velocity(self, scene_index, track_index):
        """
        Map Ableton's clip.color_index to a velocity value.
        USB-behavior fix: if no clip is present, ALWAYS return 0.
        Prevents stale color_index values after deletion.
        """
        try:
            ti = self._session.track_offset() + track_index
            si = self._session.scene_offset() + scene_index
            tracks = list(self.song().tracks)
            if ti < 0 or ti >= len(tracks):
                return 0
            slots = list(tracks[ti].clip_slots)
            if si < 0 or si >= len(slots):
                return 0
            slot = slots[si]

            # --- CRITICAL USB-BEHAVIOR FIX ---
            if not getattr(slot, 'has_clip', False):
                return 0

            clip = slot.clip
            raw = int(getattr(clip, "color_index", 0))
            raw = max(0, min(69, raw))
            return 3 + raw
        except Exception:
            return 0

    def _emit_cell(self, scene_index, track_index):
       
        note = 36 + scene_index * 8 + track_index
        # --- USB-BEHAVIOR HARD CLEAR ---
        # If the slot has no clip, FORCE velocity=0 immediately.
        try:
            ti = self._session.track_offset() + track_index
            si = self._session.scene_offset() + scene_index
            tracks = list(self.song().tracks)
            if 0 <= ti < len(tracks):
                slots = list(tracks[ti].clip_slots)
                if 0 <= si < len(slots):
                    slot = slots[si]
                    if not getattr(slot, "has_clip", False):
                        self._send_midi((0x90 + self._channel, note & 0x7F, 0))

                        # Clear run-state for this cell on isolated channel.
                        idx = (scene_index * 8 + track_index)
                        cc = RUNSTATE_CC_BASE + idx
                        self._send_midi((0xB0 + RUNSTATE_CHANNEL, cc & 0x7F, 0))
                        return
        except Exception:
            pass

        # 0 = empty; 3..72 ≈ Ableton color
        velocity = self._clip_color_velocity(scene_index, track_index)
        try:
            self._send_midi((0x90 + self._channel, note & 0x7F, velocity & 0x7F))
        except Exception as e:
            self.log_message(f"_emit_cell error: {e}")

        # Run-state feedback on isolated MIDI channel 15.
        try:
            state = self._slot_state(scene_index, track_index)
            idx = (scene_index * 8 + track_index)
            cc = RUNSTATE_CC_BASE + idx
            self._send_midi((0xB0 + RUNSTATE_CHANNEL, cc & 0x7F, _int7(state)))
        except Exception:
            pass

    def _clip_feedback(self, value, sender):
        if value == 0:
            return
        note = sender.message_identifier()
        scene_index = (note - 36) // 8
        track_index = (note - 36) % 8
        # Update target so Select actions operate on the last interacted cell
        self._target_scene = scene_index
        self._target_track = track_index
        self._emit_cell(scene_index, track_index)

    def _start_feedback_poll(self):
        if not getattr(self, '_feedback_polling', False):
            return
        try:
            # Lightweight poll: keep clip/grid state + track colors + mixer values.
            self._emit_grid_snapshot()
            self._emit_visible_track_colors()
            self._emit_mix_snapshot()   # restored to keep faders in sync
            self._broadcast_arm_state()  # ensure ARM (80..87) wins after run-state remap (86..93)
            self._push_macro_values()
            self._send_selected_track_feedback()
            # Send tempo + full transport clock (phase / beat / bar)
            self._send_tempo_snapshot()
            self._send_clock_snapshot()
            # === FAST CLIP POLLING (visible 8x4 only) ===
            try:
                for scene_index in range(4):
                    for track_index in range(8):
                        self._emit_cell(scene_index, track_index)
            except Exception:
                pass
        except Exception as e:
            self.log_message(f"_start_feedback_poll error: {e}")
        finally:
            # Maintain the same cadence
            self.schedule_message(POLL_INTERVAL_SEC, self._start_feedback_poll)

    def _emit_grid_snapshot(self):
        for scene_index in range(4):
            for track_index in range(8):
                self._emit_cell(scene_index, track_index)

    def _stop_feedback_poll(self):
        self._feedback_polling = False

    def _set_target_track_value(self, value):
        try:
            v = int(value) - 1
            if 0 <= v < 8:
                self._target_track = v
        except Exception as e:
            self.log_message(f"Target track set error: {e}")

    def _set_target_scene_value(self, value):
        try:
            v = int(value) - 1
            if 0 <= v < 4:
                self._target_scene = v
        except Exception as e:
            self.log_message(f"Target scene set error: {e}")

    def _emit_visible_track_colors(self):
        """
        Emit Ableton track color indices for the 8 visible columns as CC12..CC19.
        Each CC value is the color index (0..127), or 0 when out of range.
        The iOS app will map the index to a SwiftUI Color via LPStyle.
        """
        try:
            off = int(self._session.track_offset())
        except Exception:
            off = 0
        tracks = list(self.song().tracks)
        for i in range(8):
            ti = off + i
            if 0 <= ti < len(tracks):
                t = tracks[ti]
                # Live versions expose either color_index or color; prefer color_index
                color_id = getattr(t, 'color_index', None)
                if color_id is None:
                    color_id = getattr(t, 'color', 0)
                val = int(color_id) & 0x7F
            else:
                val = 0
            self._send_cc(CC_TRACK_COLOR_BASE + i, val)

    def disconnect(self):
        """Ensure listeners and polling are cleanly removed on unload."""
        try:
            self._feedback_polling = False
        except Exception:
            pass

        # Macros
        try:
            self._clear_macro_param_listeners()
            for b in getattr(self, "_macro_buttons", []):
                try:
                    if b and b.value_has_listener(self._on_macro_cc):
                        b.remove_value_listener(self._on_macro_cc)
                except Exception:
                    pass
        except Exception as e:
            self.log_message("disconnect macro cleanup err: %s" % e)

        # --- Clip slot listener cleanup ---
        try:
            for (slot, listener) in getattr(self, "_clip_listeners", []):
                try:
                    if slot.has_clip_has_listener(listener):
                        slot.remove_has_clip_listener(listener)
                except Exception:
                    pass
                try:
                    if slot.color_has_listener(listener):
                        slot.remove_color_listener(listener)
                except Exception:
                    pass
                try:
                    if slot.playing_status_has_listener(listener):
                        slot.remove_playing_status_listener(listener)
                except Exception:
                    pass
                try:
                    if slot.is_triggered_has_listener(listener):
                        slot.remove_is_triggered_listener(listener)
                except Exception:
                    pass
                try:
                    if slot.is_recording_has_listener(listener):
                        slot.remove_is_recording_listener(listener)
                except Exception:
                    pass
        except Exception:
            pass

        self._clip_listeners = []

        # Track arm listeners
        try:
            for (t, cb) in getattr(self, "_arm_listeners", []):
                try:
                    if t and t.arm_has_listener(cb):
                        t.remove_arm_listener(cb)
                except Exception:
                    pass
            self._arm_listeners = []
        except Exception as e:
            self.log_message("disconnect arm cleanup err: %s" % e)

        # State slots (solo/mute/enable)
        try:
            self._unbind_state_slots()
        except Exception as e:
            self.log_message("disconnect state slot err: %s" % e)

        # Selected track / tracks structure listeners
        try:
            v = self.song().view
            if v and v.selected_track_has_listener(self._on_selected_track_changed):
                v.remove_selected_track_listener(self._on_selected_track_changed)
        except Exception:
            pass
        try:
            if self.song().tracks_has_listener(self._on_tracks_structure_changed):
                self.song().remove_tracks_listener(self._on_tracks_structure_changed)
        except Exception:
            pass
        try:
            if self.song().tempo_has_listener(self._on_tempo_changed):
                self.song().remove_tempo_listener(self._on_tempo_changed)
        except Exception:
            pass

        # Buttons created with add_value_listener(...)
        try:
            for attr in (
                "_btn_target_track", "_btn_target_scene",
                "_btn_delete", "_btn_duplicate", "_btn_mute",
                "_btn_solo", "_btn_arm", "_btn_track_enable", "_btn_track_select"
            ):
                b = getattr(self, attr, None)
                if not b:
                    continue
                for h in (
                    getattr(self, "_set_target_track_value", None),
                    getattr(self, "_set_target_scene_value", None),
                    getattr(self, "_delete_clip_value", None),
                    getattr(self, "_duplicate_clip_value", None),
                    getattr(self, "_toggle_mute_value", None),
                    getattr(self, "_toggle_solo_value", None),
                    getattr(self, "_toggle_arm_value", None),
                    getattr(self, "_toggle_track_enable_value", None),
                    getattr(self, "_select_track_value", None),
                ):
                    try:
                        if h and b.value_has_listener(h):
                            b.remove_value_listener(h)
                    except Exception:
                        pass
        except Exception as e:
            self.log_message("disconnect button cleanup err: %s" % e)

        # Call parent
        try:
            super(MidiOS8x4, self).disconnect()
        except Exception:
            pass


    def _toggle_loop_value(self, value):
        if value > 0:
            try:
                self.song().loop = not self.song().loop
            except Exception as e:
                self.log_message(f"Loop toggle error: {e}")
            try:
                self._send_midi((0xB0 + self._channel, 108, 90))  # Flash feedback
                self.schedule_message(4, lambda: self._send_midi((0xB0 + self._channel, 108, 0)))
            except Exception:
                pass
