from _Framework.Capabilities import NOTES_CC, PORTS_KEY, REMOTE, SCRIPT, inport, outport

from .midiOS8x4 import MidiOS8x4


def get_capabilities():
    """Tell Live that the script input must also remain a track-note input."""
    return {
        PORTS_KEY: [
            inport(props=[NOTES_CC, SCRIPT, REMOTE]),
            outport(props=[SCRIPT, REMOTE]),
        ]
    }


def create_instance(c_instance):
    return MidiOS8x4(c_instance)
